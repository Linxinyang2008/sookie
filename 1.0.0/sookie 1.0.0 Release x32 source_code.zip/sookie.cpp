#include<cstdio>
#include"sookie.h"

bool con = 1;
point plr = START;

const point eps = (point){3, 3};
point pp;

void rex(void){
	hello();
	Ginit();
	GetObjects();
	system("cls");
}

int MySookie(void){
//	if(!DebugFileCheck())
		if( !InitFile() )rex();
		else ReadData(cFileName);
	
	start = clock();
	while(pp != DN){
		system("cls"), printx(plr, START, END, 0);
		plr = pp = control(plr);
	}
	
	return 0;
}
