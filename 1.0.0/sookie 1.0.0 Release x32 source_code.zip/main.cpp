#include"sookie.cpp"

int main(int argc, char** argv) {
	while(1){
		MySookie();
		system("cls");
	}
	return 0;
}